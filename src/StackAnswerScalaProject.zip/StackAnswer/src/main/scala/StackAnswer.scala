import java.io.File

import org.apache.spark.sql.types.{IntegerType, StringType, StructType}
import org.apache.spark.sql.{SQLContext, SparkSession}
import org.apache.spark.sql.functions._

object StackAnswer {


  def main(args: Array[String]): Unit = {
    /*val answersFile = "file:///home/ivan/tmp/KC/user_ids_answers"
    val namesFile = "file:///home/ivan/tmp/KC/user_ids_names"
    val pathWordCount = "file:///home/ivan/tmp/KC/out/user_ids_answers_wordcount"
    val pathUsersMostActives = "file:///home/ivan/tmp/KC/out/users_most_actives"
    val pathLocaltionsMostActives = "file:///home/ivan/tmp/KC/out/locations_most_actives"

    deletePath(pathUsersMostActives)
    deletePath(pathLocaltionsMostActives)
    deletePath(pathWordCount)*/

    val namesFile = "hdfs:///user/root/input_names/user_ids_names"
    val answersFile = "hdfs:///user/root/input_answers/user_ids_answers"
    val pathWordCount = "hdfs:///user/root/user_ids_answers_wordcount"
    val pathUsersMostActives = "hdfs:///user/root/users_most_actives"
    val pathLocaltionsMostActives = "hdfs:///user/root/locations_most_actives"

    val spark = SparkSession
      .builder
      .appName("StackAnswer")
      .master(master = "local[*]")
      .getOrCreate()

    // configuramos los logs para que solo muestre errores
    import org.apache.log4j.{Level, Logger}
    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)

    import spark.implicits._

    // leemos el fichero con las respuestas y hacemos un count de los ids.
    val readFileDF = spark.sparkContext.textFile(answersFile).toDF
    val name_counts = readFileDF.groupBy("Value").count().orderBy($"count".desc)
    //name_counts.show()

    val name_countsC = name_counts .coalesce(1)
    name_countsC.write.csv(pathWordCount)

    // leemos el fichero de con los nombres de los usuarios y sus localizaciones
    val schemaNames = new StructType()
      .add("user_id",     IntegerType,true)
      .add("name",        StringType,true)
      .add("reputation",  IntegerType, true)
      .add("location",    StringType, true)

    val userDataDF = spark.read
      .option("sep", ",")
      .option("header", false)
      .schema(schemaNames)
      .csv(namesFile)

    //userDataDF.show()

    // eliminamos las filas duplicadas
    val userDataCleanedDF = userDataDF.dropDuplicates()

    // hacemos un join de los datos
    val dataUsersAnswersDF = userDataCleanedDF.join(name_counts, userDataCleanedDF("user_id") === name_counts("Value"), "inner").drop("Value")
    //dataUsersAnswersDF.show()

    val usersMostActivesDF = dataUsersAnswersDF.select($"user_id", $"name", $"count".as("n_answers")).coalesce(1)
    //usersMostActivesDF.show()
    usersMostActivesDF.write.csv(pathUsersMostActives)

    val dataLocationsMostActivesDF = dataUsersAnswersDF
      .groupBy("location")
      .sum("count")
      .select($"location", $"sum(count)".as("n_answres"))
      .orderBy(desc("n_answres"))
      .coalesce(1)
    //dataLocationsMostActivesDF.show
    dataLocationsMostActivesDF.write.csv(pathLocaltionsMostActives)
  }

  def deletePath(pathO: String): Unit = {
    val path = pathO.substring(7)
    val outDir = new File(path)

    if (outDir.exists()) {
      if (outDir.isDirectory)
        outDir.listFiles().foreach(_.delete())
      outDir.delete()
    }
  }
}
